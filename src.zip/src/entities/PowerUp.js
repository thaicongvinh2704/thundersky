import { WEAPONS } from "../data/weapons.js";
import { BALANCE } from "../data/balance.js";

export class PowerUp {
  constructor(x, y, type = "energy") {
    this.x = x;
    this.y = y;
    this.vx = (Math.random() - 0.5) * 70;
    this.vy = 90 + Math.random() * 35;
    this.r = 16;
    this.type = type;
    this.spin = Math.random() * Math.PI * 2;
    this.life = 8;
  }

  update(dt) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.vy += 18 * dt;
    this.spin += dt * 5;
    this.life -= dt;
  }

  apply(player) {
    if (this.type === "repair") {
      player.health = Math.min(player.maxHealth, player.health + 18);
      return;
    }
    if (this.type.startsWith("weapon:")) {
      player.setWeapon(this.type.slice(7));
      return;
    }
    player.energy = Math.min(BALANCE.thunder.maxEnergy, player.energy + BALANCE.thunder.chargePerPickup * (1 + player.stats.thunderCharge));
  }

  draw(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate(this.spin);
    ctx.globalCompositeOperation = "lighter";
    const weapon = this.weapon();
    const color = this.type === "repair" ? "#53f4a8" : weapon ? weapon.color : "#ffe66d";
    const glow = ctx.createRadialGradient(0, 0, 0, 0, 0, 34);
    glow.addColorStop(0, "rgba(255,255,255,0.95)");
    glow.addColorStop(0.34, color);
    glow.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, 34, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(5,18,32,0.82)";
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const a = (Math.PI * 2 * i) / 6;
      const r = i % 2 === 0 ? 18 : 11;
      if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
      else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.rotate(-this.spin);
    ctx.fillStyle = color;
    ctx.font = "800 17px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(this.label(), 0, 1);
    ctx.restore();
  }

  weapon() {
    if (!this.type.startsWith("weapon:")) return null;
    return WEAPONS[this.type.slice(7)] || null;
  }

  label() {
    if (this.type === "repair") return "+";
    const weapon = this.weapon();
    return weapon ? weapon.symbol : "E";
  }
}
