import { Bullet } from "./Bullet.js";
import { BALANCE } from "../data/balance.js";
import { WEAPONS } from "../data/weapons.js";
import { clamp } from "../core/Collision.js";

export class Player {
  constructor() {
    this.r = BALANCE.player.radius;
    this.speed = BALANCE.player.speed;
    this.maxHealth = BALANCE.player.maxHealth;
    this.health = this.maxHealth;
    this.x = 0;
    this.y = 0;
    this.cooldown = 0;
    this.invincible = 0;
    this.energy = 0;
    this.thunderCooldown = 0;
    this.shields = 0;
    this.missileTimer = BALANCE.missileInterval;
    this.weapon = WEAPONS.plasma;
    this.stats = {
      fireRate: 0,
      spread: 1,
      damage: 1,
      missile: 0,
      damageReduction: 0,
      regen: 0,
      thunderDamage: 0,
      thunderRadius: 0,
      thunderCharge: 0,
      thunderCooldown: BALANCE.thunder.cooldown,
      thunderBossBonus: 0,
      thunderShield: 0
    };
    this.upgrades = [];
  }

  reset(width, height) {
    this.x = width / 2;
    this.y = height * 0.78;
    this.maxHealth = BALANCE.player.maxHealth;
    this.health = this.maxHealth;
    this.cooldown = 0;
    this.invincible = 1.2;
    this.energy = 0;
    this.thunderCooldown = 0;
    this.shields = 0;
    this.missileTimer = BALANCE.missileInterval;
    this.weapon = WEAPONS.plasma;
    this.stats = {
      fireRate: 0,
      spread: 1,
      damage: 1,
      missile: 0,
      damageReduction: 0,
      regen: 0,
      thunderDamage: 0,
      thunderRadius: 0,
      thunderCharge: 0,
      thunderCooldown: BALANCE.thunder.cooldown,
      thunderBossBonus: 0,
      thunderShield: 0
    };
    this.upgrades = [];
  }

  update(dt, input, game) {
    this.cooldown -= dt;
    this.invincible -= dt;
    this.thunderCooldown = Math.max(0, this.thunderCooldown - dt);
    if (this.stats.regen > 0 && this.health < this.maxHealth * 0.7) {
      this.health = Math.min(this.maxHealth, this.health + this.stats.regen * dt);
    }
    const axis = input.axis();
    this.x += axis.x * this.speed * dt;
    this.y += axis.y * this.speed * dt;

    if (input.pointer.active) {
      this.x += (input.pointer.x - this.x) * Math.min(1, dt * 9);
      this.y += (input.pointer.y - this.y) * Math.min(1, dt * 9);
    }

    this.x = clamp(this.x, 28, game.width - 28);
    this.y = clamp(this.y, 70, game.height - 34);

    if (input.wantsFire()) this.shoot(game);
    if (input.consumeSkillRequest()) game.activateThunder();
    this.updateMissiles(dt, game);
  }

  shoot(game) {
    if (this.cooldown > 0) return;
    const weapon = this.weapon;
    const spread = Math.min(this.stats.spread, 5);
    this.cooldown = Math.max(0.052, (BALANCE.player.baseCooldown - this.stats.fireRate * 0.018) * weapon.cooldownScale);
    const angles = this.getWeaponAngles(spread, weapon);
    for (const angle of angles) {
      const speed = (BALANCE.player.bulletSpeed + this.stats.damage * 18) * weapon.speedScale;
      game.playerBullets.push(new Bullet({
        x: this.x + angle * 64,
        y: this.y - 28,
        vx: Math.sin(angle) * speed,
        vy: -Math.cos(angle) * speed,
        r: weapon.radius + this.stats.damage * 0.45,
        damage: Math.max(1, this.stats.damage * weapon.damageScale),
        life: weapon.life,
        color: weapon.color,
        homing: Boolean(weapon.homing),
        pierce: weapon.pierce || 0,
        splash: weapon.splash || 0,
        shape: weapon.shape || "orb"
      }));
    }
    game.effects.burst(this.x, this.y - 28, weapon.color, 5 + spread + Math.floor(angles.length / 2), 140, 0.22);
    game.audio.play("shoot");
  }

  getWeaponAngles(spread, weapon) {
    const angles = this.getShotAngles(spread);
    if (!weapon.extraAngles) return angles;
    return [...angles, ...weapon.extraAngles].sort((a, b) => a - b);
  }

  getShotAngles(spread) {
    if (spread <= 1) return [0];
    if (spread === 2) return [-0.08, 0.08];
    if (spread === 3) return [-0.16, 0, 0.16];
    if (spread === 4) return [-0.22, -0.08, 0.08, 0.22];
    return [-0.28, -0.14, 0, 0.14, 0.28];
  }

  updateMissiles(dt, game) {
    if (this.stats.missile <= 0) return;
    this.missileTimer -= dt;
    if (this.missileTimer > 0) return;
    this.missileTimer = Math.max(1.25, BALANCE.missileInterval - this.stats.missile * 0.45);
    game.playerBullets.push(new Bullet({
      x: this.x,
      y: this.y - 18,
      vx: 0,
      vy: -520,
      r: 7,
      damage: 3 + this.stats.missile,
      life: 4,
      color: "#ffe66d",
      homing: true
    }));
    game.audio.play("shoot");
  }

  setWeapon(id) {
    this.weapon = WEAPONS[id] || WEAPONS.plasma;
  }

  takeDamage(amount, game) {
    if (this.invincible > 0) return;
    if (this.shields > 0) {
      this.shields -= 1;
      this.invincible = 0.55;
      game.recordPlayerHit();
      game.effects.burst(this.x, this.y, "#7fffd0", 22, 220, 0.6);
      return;
    }
    game.recordPlayerHit();
    this.health -= amount * (1 - this.stats.damageReduction);
    this.invincible = 0.85;
    game.shake = Math.min(20, game.shake + 10);
    game.effects.burst(this.x, this.y, "#ff8a5c", 12, 160, 0.42);
    game.audio.play("hit");
    if (this.health <= 0) game.gameOver();
  }

  draw(ctx) {
    ctx.save();
    ctx.translate(this.x, this.y);
    if (this.invincible > 0 && Math.floor(this.invincible * 18) % 2 === 0) ctx.globalAlpha = 0.58;

    const flame = 18 + Math.sin(performance.now() / 45) * 7;
    const flameGradient = ctx.createLinearGradient(0, 24, 0, 56);
    flameGradient.addColorStop(0, "#efffff");
    flameGradient.addColorStop(0.3, "#6fffe0");
    flameGradient.addColorStop(0.72, "#ffb347");
    flameGradient.addColorStop(1, "rgba(255,106,64,0)");
    ctx.fillStyle = flameGradient;
    ctx.beginPath();
    ctx.moveTo(-15, 23);
    ctx.lineTo(-8, 35 + flame);
    ctx.lineTo(-1, 23);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(15, 23);
    ctx.lineTo(8, 35 + flame);
    ctx.lineTo(1, 23);
    ctx.closePath();
    ctx.fill();

    ctx.shadowColor = "rgba(85,230,255,0.5)";
    ctx.shadowBlur = 18;
    ctx.fillStyle = "#8fa7b8";
    ctx.strokeStyle = "#d9f5ff";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, -46);
    ctx.lineTo(13, -20);
    ctx.lineTo(58, 4);
    ctx.lineTo(25, 14);
    ctx.lineTo(19, 31);
    ctx.lineTo(8, 24);
    ctx.lineTo(0, 34);
    ctx.lineTo(-8, 24);
    ctx.lineTo(-19, 31);
    ctx.lineTo(-25, 14);
    ctx.lineTo(-58, 4);
    ctx.lineTo(-13, -20);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    const bodyGradient = ctx.createLinearGradient(0, -45, 0, 34);
    bodyGradient.addColorStop(0, "#edf7fb");
    bodyGradient.addColorStop(0.38, "#9db2c1");
    bodyGradient.addColorStop(1, "#4e6272");
    ctx.fillStyle = bodyGradient;
    ctx.beginPath();
    ctx.moveTo(0, -48);
    ctx.quadraticCurveTo(16, -15, 12, 24);
    ctx.lineTo(0, 36);
    ctx.lineTo(-12, 24);
    ctx.quadraticCurveTo(-16, -15, 0, -48);
    ctx.closePath();
    ctx.fill();

    ctx.shadowBlur = 0;
    ctx.fillStyle = "#1b3348";
    ctx.beginPath();
    ctx.ellipse(0, -21, 7, 15, 0, 0, Math.PI * 2);
    ctx.fill();

    if (this.shields > 0) {
      ctx.strokeStyle = "rgba(127,255,208,0.7)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, -3, 64, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.restore();
  }
}
