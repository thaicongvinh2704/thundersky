export class SaveSystem {
  constructor(key = "skyThunderSaveV1") {
    this.key = key;
    this.best = this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(this.key);
      if (!raw) return { score: 0, stage: 1, enemiesDestroyed: 0, endlessTime: 0, maxCombo: 1 };
      return { score: 0, stage: 1, enemiesDestroyed: 0, endlessTime: 0, maxCombo: 1, ...JSON.parse(raw) };
    } catch {
      return { score: 0, stage: 1, enemiesDestroyed: 0, endlessTime: 0, maxCombo: 1 };
    }
  }

  saveRun(run) {
    const next = {
      score: Math.max(this.best.score || 0, run.score || 0),
      stage: Math.max(this.best.stage || 1, run.stage || 1),
      enemiesDestroyed: Math.max(this.best.enemiesDestroyed || 0, run.enemiesDestroyed || 0),
      endlessTime: Math.max(this.best.endlessTime || 0, run.endlessTime || 0),
      maxCombo: Math.max(this.best.maxCombo || 1, run.maxCombo || 1)
    };
    this.best = next;
    try {
      localStorage.setItem(this.key, JSON.stringify(next));
    } catch {
      // Ignore storage failures so embedded portals can still run the game.
    }
    return next;
  }
}
