import { Particle } from "../entities/Particle.js";

export class EffectsSystem {
  constructor(game) {
    this.game = game;
    this.particles = [];
    this.clouds = [];
    this.stars = [];
    this.lightnings = [];
    this.messages = [];
    this.maxParticles = 280;
    this.cloudTimer = 0;
  }

  reset() {
    this.particles.length = 0;
    this.clouds.length = 0;
    this.lightnings.length = 0;
    this.messages.length = 0;
    this.makeStars();
  }

  makeStars() {
    this.stars.length = 0;
    const count = Math.floor((this.game.width * this.game.height) / 9000);
    for (let i = 0; i < count; i++) {
      this.stars.push({
        x: Math.random() * this.game.width,
        y: Math.random() * this.game.height,
        z: 0.35 + Math.random() * 1.3,
        twinkle: Math.random() * Math.PI * 2
      });
    }
  }

  burst(x, y, color, count, speed, life) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) this.particles.shift();
      this.particles.push(new Particle(x, y, color, speed, life));
    }
  }

  message(text) {
    this.messages.push({ text, life: 1.8, maxLife: 1.8 });
    if (this.messages.length > 3) this.messages.shift();
  }

  explode(x, y, big = false) {
    this.burst(x, y, "#fff3a6", big ? 32 : 18, big ? 260 : 180, 0.7);
    this.burst(x, y, "#ff6c3f", big ? 24 : 12, big ? 220 : 150, 0.55);
    this.burst(x, y, "#77e7ff", big ? 16 : 8, big ? 170 : 120, 0.45);
    this.game.shake = Math.min(18, this.game.shake + (big ? 12 : 6));
  }

  thunderStorm(x, y, targets, radius) {
    for (const target of targets) {
      this.lightnings.push({
        x1: x,
        y1: y - 30,
        x2: target.x,
        y2: target.y,
        life: 0.34,
        maxLife: 0.34,
        width: target.r > 40 ? 6 : 4
      });
      this.burst(target.x, target.y, "#bdf7ff", 10, 170, 0.38);
    }
    for (let i = 0; i < 10; i++) {
      const angle = (Math.PI * 2 * i) / 10;
      this.lightnings.push({
        x1: x,
        y1: y,
        x2: x + Math.cos(angle) * radius * (0.35 + Math.random() * 0.35),
        y2: y + Math.sin(angle) * radius * (0.35 + Math.random() * 0.35),
        life: 0.24,
        maxLife: 0.24,
        width: 3
      });
    }
    this.burst(x, y, "#ffffff", 34, 320, 0.42);
    this.burst(x, y, "#77e7ff", 44, 260, 0.62);
  }

  update(dt) {
    this.cloudTimer -= dt;
    if (this.cloudTimer <= 0) {
      this.clouds.push({
        x: -120 + Math.random() * (this.game.width + 240),
        y: -80,
        s: 0.6 + Math.random() * 1.6,
        vy: 22 + Math.random() * 38,
        a: 0.08 + Math.random() * 0.13
      });
      this.cloudTimer = 0.7 + Math.random() * 0.7;
    }

    for (const star of this.stars) {
      star.y += (55 * star.z + this.game.stageSystem.stageId * 5) * dt;
      star.twinkle += dt * 4;
      if (star.y > this.game.height + 8) {
        star.y = -8;
        star.x = Math.random() * this.game.width;
      }
    }

    this.clouds = this.clouds.filter((cloud) => {
      cloud.y += cloud.vy * dt;
      return cloud.y <= this.game.height + 130;
    });

    this.particles = this.particles.filter((particle) => {
      particle.update(dt);
      return particle.life > 0;
    });

    this.lightnings = this.lightnings.filter((bolt) => {
      bolt.life -= dt;
      return bolt.life > 0;
    });

    this.messages = this.messages.filter((message) => {
      message.life -= dt;
      return message.life > 0;
    });
  }
}
