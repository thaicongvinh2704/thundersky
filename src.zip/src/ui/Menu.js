export class Menu {
  constructor(elements) {
    this.elements = elements;
  }

  bindStart(handler) {
    this.elements.startButton.addEventListener("click", handler);
  }

  bindSecondary(handler) {
    if (this.elements.secondaryButton) this.elements.secondaryButton.addEventListener("click", handler);
  }

  showMenu() {
    this.show("Sky Thunder", "Song sot qua cac wave, gom nang luong va kich hoat Thunder Storm khi day pin.", "Bat dau", true);
  }

  show(title, text, buttonText, showControls = false, secondaryText = "") {
    this.elements.overlay.classList.remove("hidden");
    this.elements.title.textContent = title;
    this.elements.text.textContent = text;
    this.elements.startButton.textContent = buttonText;
    this.elements.startButton.classList.remove("hidden");
    if (this.elements.secondaryButton) {
      this.elements.secondaryButton.textContent = secondaryText;
      this.elements.secondaryButton.classList.toggle("hidden", !secondaryText);
    }
    this.elements.controls.classList.toggle("hidden", !showControls);
    this.elements.upgradeOptions.classList.add("hidden");
    this.elements.upgradeOptions.innerHTML = "";
  }

  hide() {
    this.elements.overlay.classList.add("hidden");
  }
}
