export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.keys = new Set();
    this.pointer = { x: 0, y: 0, active: false, fire: false };
    this.skillRequested = false;
    this.autoFire = true;
    this.onStart = null;
    this.onPause = null;
    this.onDebug = null;
  }

  bind() {
    window.addEventListener("keydown", (event) => {
      this.keys.add(event.key);
      if (event.key === " ") event.preventDefault();
      if (event.key === "Enter" && this.onStart) this.onStart();
      if ((event.key === "p" || event.key === "P") && this.onPause) this.onPause();
      if (event.key === "F3" && this.onDebug) {
        event.preventDefault();
        this.onDebug();
      }
      if (event.key === "e" || event.key === "E" || event.key === "Shift") this.skillRequested = true;
    });

    window.addEventListener("keyup", (event) => this.keys.delete(event.key));

    this.canvas.addEventListener("pointermove", (event) => this.setPointer(event, false));
    this.canvas.addEventListener("pointerdown", (event) => {
      this.capturePointer(event);
      this.setPointer(event, true);
      if (this.onStart) this.onStart();
    });
    window.addEventListener("pointerup", (event) => {
      this.releasePointer(event);
      this.pointer.fire = false;
    });
  }

  setPointer(event, fire) {
    event.preventDefault();
    this.pointer.active = true;
    this.pointer.fire = fire || this.pointer.fire;
    this.pointer.x = Math.max(0, Math.min(window.innerWidth, event.clientX));
    this.pointer.y = Math.max(0, Math.min(window.innerHeight, event.clientY));
  }

  capturePointer(event) {
    if (!this.canvas.setPointerCapture || !event.pointerId) return;
    try {
      this.canvas.setPointerCapture(event.pointerId);
    } catch {
      // Some embedded browsers reject capture; the game still works normally.
    }
  }

  releasePointer(event) {
    if (!this.canvas.releasePointerCapture || !event.pointerId) return;
    try {
      this.canvas.releasePointerCapture(event.pointerId);
    } catch {
      // Pointer may already be released by the browser.
    }
  }

  axis() {
    const x = (this.keys.has("ArrowRight") || this.keys.has("d") ? 1 : 0) -
      (this.keys.has("ArrowLeft") || this.keys.has("a") ? 1 : 0);
    const y = (this.keys.has("ArrowDown") || this.keys.has("s") ? 1 : 0) -
      (this.keys.has("ArrowUp") || this.keys.has("w") ? 1 : 0);
    const len = Math.hypot(x, y) || 1;
    return { x: x / len, y: y / len };
  }

  wantsFire() {
    return this.autoFire || this.keys.has(" ") || this.pointer.fire;
  }

  requestSkill() {
    this.skillRequested = true;
  }

  consumeSkillRequest() {
    if (!this.skillRequested) return false;
    this.skillRequested = false;
    return true;
  }
}
