import { Input } from "./Input.js";
import { Renderer } from "./Renderer.js";
import { StateManager, STATES } from "./StateManager.js";
import { circleHit } from "./Collision.js";
import { Player } from "../entities/Player.js";
import { PowerUp } from "../entities/PowerUp.js";
import { WEAPON_DROP_IDS } from "../data/weapons.js";
import { BALANCE } from "../data/balance.js";
import { SpawnSystem } from "../systems/SpawnSystem.js";
import { StageSystem } from "../systems/StageSystem.js";
import { UpgradeSystem } from "../systems/UpgradeSystem.js";
import { EffectsSystem } from "../systems/EffectsSystem.js";
import { SaveSystem } from "../systems/SaveSystem.js";
import { AudioSystem } from "../systems/AudioSystem.js";
import { Hud } from "../ui/Hud.js";
import { Menu } from "../ui/Menu.js";
import { UpgradeScreen } from "../ui/UpgradeScreen.js";
import { GameOverScreen } from "../ui/GameOverScreen.js";

export class Game {
  constructor({ canvas, hud, menu }) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.width = 0;
    this.height = 0;
    this.dpr = 1;
    this.states = STATES;
    this.lastTime = 0;
    this.score = 0;
    this.shake = 0;
    this.playerBullets = [];
    this.enemyBullets = [];
    this.enemies = [];
    this.powerUps = [];
    this.boss = null;
    this.running = false;
    this.loopId = 0;
    this.stats = { enemiesDestroyed: 0, stageReached: 1, maxCombo: 1, endlessTime: 0, stageHits: 0, totalHits: 0, bossTime: 0 };
    this.combo = { count: 0, multiplier: 1, timer: 0, maxTimer: 3.2 };
    this.endless = { active: false, time: 0, multiplier: 1, survivalBonusTimer: 0 };
    this.debug = { visible: false, fps: 0, frames: 0, elapsed: 0 };

    this.state = new StateManager();
    this.input = new Input(canvas);
    this.player = new Player();
    this.effects = new EffectsSystem(this);
    this.spawnSystem = new SpawnSystem(this);
    this.stageSystem = new StageSystem(this);
    this.upgradeSystem = new UpgradeSystem(this);
    this.save = new SaveSystem();
    this.audio = new AudioSystem(hud.muteButton);
    this.renderer = new Renderer(this);
    this.hud = new Hud(hud);
    this.menu = new Menu(menu);
    this.upgradeScreen = new UpgradeScreen(menu);
    this.gameOverScreen = new GameOverScreen(this.menu);
  }

  init() {
    this.resize();
    window.addEventListener("resize", () => this.resize());
    this.input.onStart = () => {
      if (this.state.is(STATES.WIN)) this.continueEndless();
      else if (this.state.is(STATES.MENU) || this.state.is(STATES.GAME_OVER)) this.start();
    };
    this.input.onPause = () => this.togglePause();
    this.input.onDebug = () => this.toggleDebug();
    this.input.bind();
    this.audio.bind();
    if (this.hud.elements.skillButton) {
      this.hud.elements.skillButton.addEventListener("click", () => this.input.requestSkill());
    }
    this.menu.bindStart(() => {
      if (this.state.is(STATES.PAUSED)) this.resume();
      else if (this.state.is(STATES.WIN)) this.continueEndless();
      else this.start();
    });
    this.menu.bindSecondary(() => this.start());
    this.menu.showMenu();
    this.audio.startMusic("menu");
    this.renderer.render(0);
  }

  resize() {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.width = window.innerWidth;
    this.height = window.innerHeight;
    this.canvas.width = Math.floor(this.width * this.dpr);
    this.canvas.height = Math.floor(this.height * this.dpr);
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    if (!this.state.is(STATES.PLAYING) && !this.state.is(STATES.BOSS) && !this.state.is(STATES.ENDLESS)) {
      this.player.x = this.width / 2;
      this.player.y = this.height * 0.78;
    }
    this.effects.makeStars();
  }

  start() {
    if (this.running) this.stopLoop();
    this.reset();
    this.audio.ensure();
    this.audio.startMusic("gameplay");
    this.state.set(STATES.PLAYING);
    this.menu.hide();
    this.lastTime = performance.now();
    this.running = true;
    this.loopId = requestAnimationFrame((time) => this.loop(time));
  }

  reset() {
    this.score = 0;
    this.shake = 0;
    this.stats = { enemiesDestroyed: 0, stageReached: 1, maxCombo: 1, endlessTime: 0, stageHits: 0, totalHits: 0, bossTime: 0 };
    this.combo = { count: 0, multiplier: 1, timer: 0, maxTimer: 3.2 };
    this.endless = { active: false, time: 0, multiplier: 1, survivalBonusTimer: 0 };
    this.debug.frames = 0;
    this.debug.elapsed = 0;
    this.playerBullets.length = 0;
    this.enemyBullets.length = 0;
    this.enemies.length = 0;
    this.powerUps.length = 0;
    this.boss = null;
    this.player.reset(this.width, this.height);
    this.effects.reset();
    this.spawnSystem.reset();
    this.stageSystem.reset();
    this.hud.update(this);
  }

  continueEndless() {
    if (this.running) this.stopLoop();
    this.endless.active = true;
    this.endless.time = 0;
    this.endless.multiplier = 1;
    this.endless.survivalBonusTimer = 0;
    this.stats.stageReached = Math.max(this.stats.stageReached, 6);
    this.boss = null;
    this.playerBullets.length = 0;
    this.enemyBullets.length = 0;
    this.enemies.length = 0;
    this.powerUps.length = 0;
    this.spawnSystem.reset();
    this.state.set(STATES.ENDLESS);
    this.menu.hide();
    this.audio.ensure();
    this.audio.startMusic("gameplay");
    this.warn("Endless Mode");
    this.lastTime = performance.now();
    this.running = true;
    this.loopId = requestAnimationFrame((time) => this.loop(time));
  }

  loop(time) {
    if (!this.running) return;
    if (this.state.is(STATES.MENU) || this.state.is(STATES.GAME_OVER) || this.state.is(STATES.WIN)) {
      this.stopLoop();
      return;
    }
    const dt = Math.min(0.033, (time - this.lastTime) / 1000);
    this.lastTime = time;

    if (!this.state.is(STATES.PAUSED) && !this.state.is(STATES.UPGRADE)) {
      this.update(dt);
    }
    this.renderer.render(time);
    this.hud.update(this);
    this.updateDebug(dt);
    this.loopId = requestAnimationFrame((nextTime) => this.loop(nextTime));
  }

  stopLoop() {
    this.running = false;
    if (this.loopId) cancelAnimationFrame(this.loopId);
    this.loopId = 0;
  }

  update(dt) {
    this.shake = Math.max(0, this.shake - dt * 35);
    this.effects.update(dt);

    this.updateCombo(dt);

    if (this.state.is(STATES.PLAYING) || this.state.is(STATES.BOSS) || this.state.is(STATES.ENDLESS)) {
      this.player.update(dt, this.input, this);
      if (this.state.is(STATES.ENDLESS)) this.updateEndless(dt);
      else {
        this.spawnSystem.update(dt);
        this.stageSystem.update(dt);
      }
      if (this.state.is(STATES.BOSS)) this.stats.bossTime += dt;
      if (this.boss) this.boss.update(dt, this);
      this.updateEntities(dt);
      this.checkCollisions();
    }
  }

  updateEntities(dt) {
    this.playerBullets = this.playerBullets.filter((bullet) => {
      bullet.update(dt, this);
      return bullet.life > 0 && bullet.y > -80 && bullet.y < this.height + 80 && bullet.x > -80 && bullet.x < this.width + 80;
    });
    this.enemyBullets = this.enemyBullets.filter((bullet) => {
      bullet.update(dt, this);
      return bullet.life > 0 && bullet.y < this.height + 80;
    });
    this.enemies = this.enemies.filter((enemy) => {
      enemy.update(dt, this);
      return enemy.y <= this.height + 80 && enemy.hp > 0;
    });
    this.powerUps = this.powerUps.filter((powerUp) => {
      powerUp.update(dt);
      return powerUp.life > 0 && powerUp.y < this.height + 50;
    });
    this.enforceSoftCaps();
  }

  enforceSoftCaps() {
    if (this.playerBullets.length > 180) this.playerBullets.splice(0, this.playerBullets.length - 180);
    if (this.enemyBullets.length > 260) this.enemyBullets.splice(0, this.enemyBullets.length - 260);
    if (this.powerUps.length > 24) this.powerUps.splice(0, this.powerUps.length - 24);
  }

  checkCollisions() {
    for (let i = this.playerBullets.length - 1; i >= 0; i--) {
      const bullet = this.playerBullets[i];
      if (this.boss && circleHit(bullet, this.boss, bullet.r, this.boss.r * 0.9)) {
        this.playerBullets.splice(i, 1);
        if (this.boss.takeDamage(bullet.damage)) this.defeatBoss();
        continue;
      }

      for (let j = this.enemies.length - 1; j >= 0; j--) {
        const enemy = this.enemies[j];
        if (!circleHit(bullet, enemy)) continue;
        if (bullet.pierce > 0) bullet.pierce -= 1;
        else this.playerBullets.splice(i, 1);
        this.effects.burst(bullet.x, bullet.y, bullet.color || "#ffe66d", 6, 90, 0.25);
        const killed = enemy.takeDamage(bullet.damage);
        if (bullet.splash > 0) this.splashDamage(bullet, enemy);
        if (killed) this.killEnemy(this.enemies.indexOf(enemy), enemy);
        break;
      }
    }

    for (let i = this.enemyBullets.length - 1; i >= 0; i--) {
      const bullet = this.enemyBullets[i];
      if (!circleHit(bullet, this.player)) continue;
      this.enemyBullets.splice(i, 1);
      this.player.takeDamage(bullet.damage, this);
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      if (!circleHit(enemy, this.player, enemy.r * 0.72, this.player.r * 0.82)) continue;
      this.enemies.splice(i, 1);
      this.effects.explode(enemy.x, enemy.y, enemy.type === "tank");
      this.player.takeDamage(enemy.type === "tank" ? 28 : 18, this);
    }

    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      const powerUp = this.powerUps[i];
      if (!circleHit(powerUp, this.player)) continue;
      this.powerUps.splice(i, 1);
      powerUp.apply(this.player);
      this.addScore(15);
      this.effects.burst(this.player.x, this.player.y, "#7fffd0", 20, 200, 0.55);
    }
  }

  killEnemy(index, enemy) {
    if (index < 0) return;
    this.enemies.splice(index, 1);
    this.stats.enemiesDestroyed += 1;
    this.registerComboKill();
    this.addScore(enemy.config.score * (enemy.scoreScale || 1), true);
    this.player.energy = Math.min(BALANCE.thunder.maxEnergy, this.player.energy + this.energyGain(enemy.config.miniBoss ? 18 : BALANCE.thunder.chargePerKill));
    if (Math.random() < (enemy.type === "tank" ? 0.42 : 0.22)) {
      this.powerUps.push(new PowerUp(enemy.x, enemy.y, this.rollPowerUpType(enemy)));
    }
    this.effects.explode(enemy.x, enemy.y, enemy.type === "tank");
    this.audio.play("explosion");
  }

  energyGain(base) {
    return base * (1 + this.player.stats.thunderCharge);
  }

  rollPowerUpType(enemy) {
    const weaponChance = enemy.type === "tank" ? 0.45 : 0.28;
    if (Math.random() < weaponChance) {
      const id = WEAPON_DROP_IDS[Math.floor(Math.random() * WEAPON_DROP_IDS.length)];
      return `weapon:${id}`;
    }
    return Math.random() < 0.42 ? "repair" : "energy";
  }

  splashDamage(bullet, directHit) {
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const enemy = this.enemies[i];
      if (enemy === directHit) continue;
      const distance = Math.hypot(enemy.x - bullet.x, enemy.y - bullet.y);
      if (distance > bullet.splash + enemy.r) continue;
      this.effects.burst(enemy.x, enemy.y, bullet.color, 5, 80, 0.18);
      if (enemy.takeDamage(bullet.damage * 0.55)) this.killEnemy(i, enemy);
    }
  }

  defeatBoss() {
    const timeBonus = Math.max(0, 1800 - Math.floor((this.stats.bossTime || 0) * 18));
    this.addScore(1200 + timeBonus);
    this.warn(timeBonus > 0 ? `Boss Time Bonus +${timeBonus}` : "Boss Clear");
    this.effects.explode(this.boss.x, this.boss.y, true);
    this.boss = null;
    this.win();
  }

  addScore(amount, useMultipliers = false) {
    const combo = useMultipliers ? this.combo.multiplier : 1;
    const endless = useMultipliers ? this.endless.multiplier : 1;
    this.score += Math.max(0, Math.floor(amount * combo * endless));
  }

  registerComboKill() {
    this.combo.count += 1;
    this.combo.timer = this.combo.maxTimer;
    this.combo.multiplier = Math.min(4.5, 1 + Math.floor(this.combo.count / 3) * 0.25);
    this.stats.maxCombo = Math.max(this.stats.maxCombo, this.combo.multiplier);
  }

  updateCombo(dt) {
    if (this.combo.timer <= 0) return;
    this.combo.timer -= dt;
    if (this.combo.timer <= 0) this.resetCombo();
  }

  resetCombo() {
    this.combo.count = 0;
    this.combo.multiplier = 1;
    this.combo.timer = 0;
  }

  recordPlayerHit() {
    this.stats.stageHits += 1;
    this.stats.totalHits += 1;
    this.resetCombo();
  }

  awardStageClearBonus(stageId) {
    const clearBonus = 450 + stageId * 180;
    this.addScore(clearBonus);
    if (this.stats.stageHits === 0) {
      const noHitBonus = 850 + stageId * 220;
      this.addScore(noHitBonus);
      this.warn(`No-hit Bonus +${noHitBonus}`);
    } else {
      this.warn(`Stage Clear +${clearBonus}`);
    }
  }

  resetStageRunStats() {
    this.stats.stageHits = 0;
    this.stats.bossTime = 0;
  }

  updateEndless(dt) {
    this.endless.time += dt;
    this.stats.endlessTime = Math.max(this.stats.endlessTime, this.endless.time);
    this.endless.multiplier = Math.min(2.5, 1 + this.endless.time / 120);
    this.spawnSystem.updateEndless(dt);
    this.endless.survivalBonusTimer += dt;
    if (this.endless.survivalBonusTimer >= 15) {
      this.endless.survivalBonusTimer = 0;
      const bonus = 250 + Math.floor(this.endless.time * 8);
      this.addScore(bonus, true);
      this.warn(`Survival Bonus +${bonus}`);
    }
  }

  warn(text) {
    this.effects.message(text);
    this.audio.play("warning");
  }

  toggleDebug() {
    this.debug.visible = !this.debug.visible;
    if (this.hud.elements.debugOverlay) this.hud.elements.debugOverlay.classList.toggle("hidden", !this.debug.visible);
  }

  updateDebug(dt) {
    this.debug.frames += 1;
    this.debug.elapsed += dt;
    if (this.debug.elapsed >= 0.5) {
      this.debug.fps = Math.round(this.debug.frames / this.debug.elapsed);
      this.debug.frames = 0;
      this.debug.elapsed = 0;
    }
    const overlay = this.hud.elements.debugOverlay;
    if (!overlay || !this.debug.visible) return;
    overlay.textContent = [
      `FPS ${this.debug.fps}`,
      `State ${this.state.state}`,
      `Enemies ${this.enemies.length}`,
      `P Bullets ${this.playerBullets.length}`,
      `E Bullets ${this.enemyBullets.length}`,
      `Particles ${this.effects.particles.length}`,
      `PowerUps ${this.powerUps.length}`,
      `Endless ${Math.floor(this.endless.time)}s`
    ].join("\n");
  }

  activateThunder() {
    const player = this.player;
    if (player.energy < BALANCE.thunder.cost || player.thunderCooldown > 0) return false;
    const radius = BALANCE.thunder.radius + player.stats.thunderRadius;
    const enemyDamage = BALANCE.thunder.enemyDamage + player.stats.thunderDamage * 8;
    const bossDamage = BALANCE.thunder.bossDamage + player.stats.thunderDamage * 35 + player.stats.thunderBossBonus;
    const targets = this.enemies.filter((enemy) => Math.hypot(enemy.x - player.x, enemy.y - player.y) <= radius + enemy.r);

    player.energy = 0;
    player.thunderCooldown = player.stats.thunderCooldown;
    this.shake = Math.min(30, this.shake + 24);
    this.enemyBullets.length = 0;

    for (let i = targets.length - 1; i >= 0; i--) {
      const enemy = targets[i];
      if (enemy.takeDamage(enemyDamage)) {
        this.killEnemy(this.enemies.indexOf(enemy), enemy);
      } else {
        this.effects.burst(enemy.x, enemy.y, "#bdf7ff", 14, 190, 0.35);
      }
    }

    if (this.boss && Math.hypot(this.boss.x - player.x, this.boss.y - player.y) <= radius + this.boss.r) {
      if (this.boss.takeDamage(bossDamage)) this.defeatBoss();
    }

    if (player.stats.thunderShield > 0) player.shields = Math.max(player.shields, 2);
    this.effects.thunderStorm(player.x, player.y, this.boss ? [this.boss, ...targets] : targets, radius);
    this.audio.play("thunder");
    return true;
  }

  openUpgrade() {
    this.state.set(STATES.UPGRADE);
    const choices = this.upgradeSystem.choices();
    this.upgradeScreen.show(choices, (upgrade) => {
      this.upgradeScreen.hide();
      this.upgradeSystem.apply(upgrade);
      this.lastTime = performance.now();
    });
  }

  findNearestTarget(x, y) {
    const targets = this.boss ? [this.boss, ...this.enemies] : this.enemies;
    let best = null;
    let bestDistance = Infinity;
    for (const target of targets) {
      const distance = Math.hypot(target.x - x, target.y - y);
      if (distance < bestDistance) {
        best = target;
        bestDistance = distance;
      }
    }
    return best;
  }

  gameOver() {
    this.effects.explode(this.player.x, this.player.y, true);
    this.state.set(STATES.GAME_OVER);
    this.finishRun();
    this.gameOverScreen.show(this);
  }

  win() {
    this.state.set(STATES.WIN);
    this.finishRun();
    this.gameOverScreen.win(this);
  }

  finishRun() {
    this.stats.stageReached = Math.max(this.stats.stageReached, this.stageSystem.stageId);
    this.save.saveRun({
      score: this.score,
      stage: this.stats.stageReached,
      enemiesDestroyed: this.stats.enemiesDestroyed,
      endlessTime: this.stats.endlessTime,
      maxCombo: this.stats.maxCombo
    });
    this.audio.startMusic("menu");
  }

  togglePause() {
    if (this.state.is(STATES.PLAYING) || this.state.is(STATES.BOSS) || this.state.is(STATES.ENDLESS)) {
      this.state.set(STATES.PAUSED);
      this.gameOverScreen.paused();
      return;
    }
    if (this.state.is(STATES.PAUSED)) this.resume();
  }

  resume() {
    this.menu.hide();
    this.state.set(this.endless.active ? STATES.ENDLESS : this.stageSystem.currentStage()?.boss ? STATES.BOSS : STATES.PLAYING);
    this.lastTime = performance.now();
  }
}
