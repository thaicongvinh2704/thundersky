export const BALANCE = {
  player: {
    speed: 450,
    radius: 19,
    maxHealth: 100,
    baseCooldown: 0.13,
    bulletSpeed: 820
  },
  thunder: {
    maxEnergy: 100,
    cost: 100,
    cooldown: 5.8,
    radius: 620,
    enemyDamage: 18,
    bossDamage: 120,
    chargePerKill: 7,
    chargePerPickup: 28
  },
  stageClearDelay: 0.85,
  missileInterval: 3.4
};
